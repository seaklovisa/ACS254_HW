﻿using StrategyPatternHW_Discount;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternHW
{
    public class MovieTicket
    {
        private IDiscount discount;
        private IBenefit benefit;

        private int PeopleNumber { get; set; }

        private System.Windows.Forms.ComboBox combo = new System.Windows.Forms.ComboBox();

        public MovieTicket()
        {
        }
    }
}