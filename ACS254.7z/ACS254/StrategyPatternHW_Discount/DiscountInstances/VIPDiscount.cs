﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPatternHW_Discount.DiscountInstances
{
    /// <summary>
    /// 花旗卡可以半價 可累積點數
    /// </summary>
    public class VIPDiscount : IDiscount, IBenefit
    {
        public MoneyEventArgs Calculate(MoneyEventArgs price)
        {
            price.TicketPrice = Convert.ToInt32(Math.Floor(price.TicketPrice * 0.5));
            return price;
        }

        //100元換一點
        public int BenefitCount(MoneyEventArgs price)
        {
            return price.TicketPrice / 100;
        }
    }
}